package Info;

import Generations.IDGenerator;

/**
 * Created by ������ on 11.11.2015.
 */
public class Task  {
   private String info;
    private IDGenerator id;
}
