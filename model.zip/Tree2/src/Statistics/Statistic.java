package Statistics;

import Info.Task;
import Tree.TreeNode;

/**
 * Created by ������ on 11.11.2015.
 */
public class Statistic extends TreeNode implements TreeTask  {
    private TreeNode id;
    private  Task info;

}
