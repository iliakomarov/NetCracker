package Info;

/**
 * Created by Ilia Komarov on 14.03.2016.
 */
public interface InfoAvailable {
    public Info getSimpleInfo();
}
