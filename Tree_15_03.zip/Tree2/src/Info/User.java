package Info;

import Info.Info;
import Tree.TaskTree;

/**
 * Created by Ilia Komarov on 23.02.2016.
 */
public class User implements InfoAvailable {
    private String name, surname, login, password;
    private TaskTree privateTree;

    public User() {
        this("def", "def", "def", "def");
    }

    public User(String name, String surname, String login, String password) {
        this.name = name;
        this.surname = surname;
        this.login = login;
        this.password = password;
        this.privateTree = new TaskTree(this);
    }

    public Info getSimpleInfo() {
        return new Info(name, login);
    }
}
