package UI;

import Exceptions.BusyTaskException;
import Info.Statistic;
import Tree.TaskTree;
import Tree.TaskTreeNode;
import Info.User;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.*;

public class TabbedPaneExample extends JFrame {
    private RequestTaskName req = new RequestTaskName();
    private JTabbedPane tabbedPane;
    private JTree tree;
    private TaskMenu nodeMenu;
    private JMenuBar menu;
    private JFrame statistic;

    private void makeTree() {
        TaskTree model = new TaskTree(new User());
        model.addTask("Math");
        model.addTask("Physics");
        model.addTask("Programming");
        model.seekForTaskByID(0).addSubtask("Algebra");
        model.seekForTaskByID(0).addSubtask("Geometry");
        model.seekForTaskByID(1).addSubtask("Hydrodynamics");
        model.seekForTaskByID(1).addSubtask("Electricity");
        model.seekForTaskByID(1).addSubtask("Mechanics");
        model.seekForTaskByID(2).addSubtask("Java");
        model.seekForTaskByID(2).addSubtask("SQL");
        model.seekForTaskByID(2).addSubtask("C++");
        model.seekForTaskByID(2).addSubtask("Scilab");
        //create the tree by passing in the root node
        tree = new JTree(model);
        tree.setBackground(Color.GRAY);
    }

    private void updateTree() {
        tabbedPane.removeAll();
        DefaultMutableTreeNode root = (DefaultMutableTreeNode) tree.getModel().getRoot();
        for (int i = 0; i < root.getChildCount(); i++) {
            JPanel panel = new JPanel();
            JTree jTree = new JTree(root.getChildAt(i), true);
            jTree.setLocation(panel.getLocation());
            jTree.setSize(240, 160);
            panel.setLayout(new BorderLayout());
            panel.add(jTree, BorderLayout.CENTER);
            JScrollPane scrollPane = new JScrollPane();
            scrollPane.setViewportView(panel);
            tabbedPane.addTab("Task", scrollPane);
            jTree.addTreeSelectionListener(new TreeSelectionListener() {
                @Override
                public void valueChanged(TreeSelectionEvent e) {
                    if (nodeMenu != null) nodeMenu.setVisible(false);
                    nodeMenu = new TaskMenu(jTree);
                    nodeMenu.setLocation(MouseInfo.getPointerInfo().getLocation());
                    nodeMenu.setVisible(true);
                }
            });
            scrollPane.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (nodeMenu != null) nodeMenu.setVisible(false);
                }
            });
            tabbedPane.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (nodeMenu != null) nodeMenu.setVisible(false);
                }
            });
        }
    }

    private void makeMenu() {
        menu = new JMenuBar();
        JMenu menuAdd = new JMenu("Add task");
        JMenu menuStat = new JMenu("Statistics");
        JMenu menuUser = new JMenu("Change user");

        menuAdd.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (req.showDialog() == 1) {
                    TaskTreeNode newChild = new TaskTreeNode(req.getTaskName());
                    DefaultTreeModel model = (DefaultTreeModel) tree.getModel();
                    DefaultMutableTreeNode node = (DefaultMutableTreeNode) model.getRoot();
                    model.insertNodeInto(newChild, node, node.getChildCount());
                }
                updateTree(); //TODO client
            }
        });
        menuStat.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Statistic stat = null;
                try {
                    stat = ((TaskTree) tree.getModel()).getStatistic();
                } catch (BusyTaskException e1) {
                    e1.printStackTrace();//TODO exception
                }
                if (statistic != null) statistic.dispose();
                statistic = new StatisticWindow(stat);
                statistic.setVisible(true);
            }
        });
        menuUser.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                dispose(); //TODO client
                new Authorization().setVisible(true);
            }
        });

        menu.add(menuAdd);
        menu.add(menuStat);
        menu.add(menuUser);
        setJMenuBar(menu);
    }

    public TabbedPaneExample() {
        setTitle("Task Tracker");
        setBackground(Color.gray);
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BorderLayout());
        getContentPane().add(topPanel);
        tabbedPane = new JTabbedPane();

        makeTree();

        makeMenu();

        updateTree(); //TODO client

        topPanel.add(tabbedPane, BorderLayout.CENTER);

        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                if (nodeMenu != null) {
                    nodeMenu.setVisible(false);
                }
                dispose();
                System.exit(0);
            }
        });
    }

    // Main method to get things started
    public static void main(String args[]) {
        // Create an instance of the test application
        TabbedPaneExample mainFrame = new TabbedPaneExample();
        mainFrame.pack();
        mainFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        mainFrame.setLocationRelativeTo(null);
        mainFrame.setSize(new Dimension(800, 600));
        mainFrame.setMinimumSize(new Dimension(640, 480));
        mainFrame.setVisible(true);
    }
}